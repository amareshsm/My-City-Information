<div class="copyrights">
	 <p>© 2019 City_info. All Rights Reserved |  <a href="#">City_info</a> </p>
</div>	
