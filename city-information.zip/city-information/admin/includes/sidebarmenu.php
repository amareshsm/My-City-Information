<div class="sidebar-menu">
					<header class="logo1">
						<a href="#" class="sidebar-icon"> <span class="fa fa-bars"></span> </a> 
					</header>
						<div style="border-top:1px ridge rgba(255, 255, 255, 0.15)"></div>
                           <div class="menu">
									<ul id="menu" >
										<li><a href="dashboard.php"><i class="fa fa-tachometer"></i> <span>Dashboard</span><div class="clearfix"></div></a></li>
										
		 <li id="menu-academico" ><a href="#"><i class="fa fa-list-ul" aria-hidden="true"></i><span> Places</span> <span class="fa fa-angle-right" style="float: right"></span><div class="clearfix"></div></a>


		  <ul id="menu-academico-sub" style="overflow-y: scroll;height:450px;" >
		<li id="menu-academico-avaliacoes" ><a href="create-package.php">Add Temples</a></li>
		<li id="menu-academico-avaliacoes" ><a href="manage-packages.php">Manage Temples</a></li>


     <li id="menu-academico-avaliacoes" ><a href="colleges.php">Add Colleges </a></li>
		<li id="menu-academico-avaliacoes" ><a href="manage-colleges.php">Manage Colleges</a></li>
    
     <li id="menu-academico-avaliacoes" ><a href="schools.php">Add schools  </a></li>
		<li id="menu-academico-avaliacoes" ><a href="manage-schools.php">Manage schools</a></li>

     <li id="menu-academico-avaliacoes" ><a href="hospitals.php">Add Hospitals  </a></li>
		<li id="menu-academico-avaliacoes" ><a href="manage-hospitals.php">Manage Hospitals</a></li>

     <li id="menu-academico-avaliacoes" ><a href="hotels.php">Add Hotels </a></li>
		<li id="menu-academico-avaliacoes" ><a href="manage-hotels.php">Manage Hotels</a></li>
<li id="menu-academico-avaliacoes" ><a href="busstand.php">Add Bus Stand</a></li>
		<li id="menu-academico-avaliacoes" ><a href="manage-busstand.php">Manage Bus Stand</a></li>


<li id="menu-academico-avaliacoes" ><a href="shoppingcenter.php">Add shopping center</a></li>
		<li id="menu-academico-avaliacoes" ><a href="manage-shoppingcenter.php">Manage shopping center</a></li>

<li id="menu-academico-avaliacoes" ><a href="railway.php">Add Railway Station </a></li>
		<li id="menu-academico-avaliacoes" ><a href="manage-railway.php">Manage Railway Station  </a></li>

<li id="menu-academico-avaliacoes" ><a href="museum.php">Add Museum </a></li>
		<li id="menu-academico-avaliacoes" ><a href="manage-museum.php">Manage Museum  </a></li>

		<li id="menu-academico-avaliacoes" ><a href="church.php">Add church</a></li>
		<li id="menu-academico-avaliacoes" ><a href="manage-church.php">Manage church  </a></li>


		<li id="menu-academico-avaliacoes" ><a href="airport.php">Add Airport</a></li>
		<li id="menu-academico-avaliacoes" ><a href="manage-airport.php">Manage Airport </a></li>

<li id="menu-academico-avaliacoes" ><a href="mosque.php">Add Mosque</a></li>
		<li id="menu-academico-avaliacoes" ><a href="manage-mosque.php">Manage Mosque </a></li>


										  </ul>
										</li>
									<li id="menu-academico" ><a href="manage-users.php"><i class="fa fa-users" aria-hidden="true"></i><span>Manage Users</span><div class="clearfix"></div></a></li>
									
									
									 <li><a href="manageissues.php"><i class="fa fa-table"></i>  <span>Manage Issues</span><div class="clearfix"></div></a></li>
									<li><a href="manage-enquires.php"><i class="fa fa-file-text-o" aria-hidden="true"></i>  <span>Manage Enquiries</span><div class="clearfix"></div></a></li>
									<li><a href="manage-pages.php"><i class="fa fa-file-text-o" aria-hidden="true"></i>  <span>Manage Pages</span><div class="clearfix"></div></a></li>
							     
									
								  </ul>
								</div>
							  </div>